package  CMMS.SetupTest1.TestCases;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import java.io.File;
import java.time.Duration;
//import org.openqa.selenium.By;
//import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
//import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import CMMS.SetupTest1.PageObjects.PO_Common;
import CMMS.SetupTest1.TestCases.Utils.BrowserManager;

public class CMMS_BR_1_13
{
	@Test
	@Parameters ({"browser", "url", "username", "password"})
	public void BR_1_13(String browser, String url, String username, String password) throws InterruptedException {
		
		// Creates instance of driver based on specified browser and url
		WebDriver driver = BrowserManager.getDriver(browser,url);
		// Initializing Page Object for PO_Common class using provided driver instance
		PO_Common obj = PageFactory.initElements(driver, PO_Common.class);

		try {
			// Log into CMMS Dev website
			obj.Login_To_CMMS_Dev(driver, username, password);
		
			// Pause for 8 seconds
			Thread.sleep(8000);
			
			// Take screenshot of results
			obj.takeScreenshotWithTaskbar();
		
			// Click Administration dropdown menu
			//obj.ClickAdminDropdown();
		
			// Click Security menu option
			//obj.ClickSecurityMenuItem();
		
			// Click User Group menu option
			//obj.ClickUserGroupMenuItem();
		
			// Pause for 5 seconds
			//Thread.sleep(5000);
		
			// Click on search bar on User Group page
			//obj.ClickUserGroupSearchBar();
		
			// Search for PLNSCH group
			//obj.EnterUserGroup();
		
			// Select first option in search
			//obj.SelectFirstOption();
		
			// Click Users tab
			//obj.ClickUsersTab();
		
			// Click search bar in User tab on User Group page
			//obj.ClickUsersSearchBar();
		
			// Enter user info (NRODGERS)
			//obj.EnterUserInfo();
			
			// Pause for 5 seconds
			//Thread.sleep(5000);
		
			// Take screenshot of results
			//obj.takeScreenshot();
		
		} catch (PO_Common.stepFailure e) {
			driver.quit();
			Assert.fail("Test failed due to step error.");
		}
		
		
		
		
		
		
		//This timeout is used to specify the time the driver should wait while 
		//searching for an element if it is not immediately present.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.close();

	}
}
