package  CMMS.SetupTest1.TestCases.Utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.Reporter;

public class BrowserManager {
    private static String timestamp;
    private static void refreshTimestamp() {
        // Update the timestamp with the current date and time
        timestamp = new SimpleDateFormat("dd-MMM-yy HH:mm:ss").format(new Date());
    }
    public static WebDriver getDriver(String type, String url) {
        WebDriver driver = null;
        if (type.equalsIgnoreCase("chrome")) {
            driver = new ChromeDriver();
        } else if (type.equalsIgnoreCase("firefox")) {
            driver = new FirefoxDriver();
        } else if (type.equalsIgnoreCase("edge")) {
            EdgeOptions options = new EdgeOptions();
            options.addArguments("--disable-notifications"); // This argument can help disable popups
            options.addArguments("--disable-popup-blocking"); // Prevents popup blocking
            options.addArguments("--disable-extensions"); // Disable all extensions
            options.addArguments("--disable-infobars"); // Disables infobars, like "Chrome is being controlled by automated test software"
            options.addArguments("--start-maximized"); // Starts browser maximized, alternative to driver.manage().window().maximize();
            // Additional options to prevent initial popups
            options.addArguments("--no-first-run");
            options.addArguments("--no-default-browser-check");
            options.addArguments("--guest");
            driver = new EdgeDriver(options);
        } else {
            Assert.assertTrue(false, "No Browser Sent");
        }
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        // The window maximization code is not needed if "--start-maximized" is used
        // driver.manage().window().maximize();
        refreshTimestamp();
        Reporter.log("Go to website: " + url, true);
        Reporter.log("Website access success.", true);
        Reporter.log(timestamp, true);
        return driver;
    }
}