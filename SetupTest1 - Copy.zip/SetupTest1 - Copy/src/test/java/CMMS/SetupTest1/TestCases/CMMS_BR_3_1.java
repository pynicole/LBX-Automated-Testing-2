package  CMMS.SetupTest1.TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.IReporter;
import org.testng.ITestListener;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import  CMMS.SetupTest1.PageObjects.PO_Common;
import  CMMS.SetupTest1.TestCases.Utils.BrowserManager;

public class CMMS_BR_3_1
{
	
	@Test
	@Parameters ({"browser", "url", "username", "password"})
	public void BR_3_1(String browser, String url, String username, String password) throws InterruptedException {
		
		// Creates instance of driver based on specified browser and url
		WebDriver driver = BrowserManager.getDriver(browser,url);
		// Initializing Page Object for PO_Common class using provided driver instance
		PO_Common obj = PageFactory.initElements(driver, PO_Common.class);
		
		try {
			// Log into CMMS Dev website
			obj.Login_To_CMMS_Dev(driver, username, password);
		
			// Pause for 10 seconds
			Thread.sleep(10000);
			
			obj.ClickOKButton();
		
			// Click Equipment dropdown button
			obj.ClickEquipmentMenu();
		
			// Click Equipment option on Equipment dropdown menu
			obj.ClickEquipmentSelection();
		
			// Click New Record button
			obj.ClickNewRecord();
		
			// Enter Equipment Name
			obj.EnterEquipmentName();
		
			// Enter Equipment Description
			obj.EnterEquipmentDesc();
		
			// Enter Equipment Type
			obj.EnterEquipmentType();
		
			// Enter Equipment Department
			obj.EnterEquipmentDept();
		
			// Click Save Record button
			obj.ClickSaveRecord();
		
			// Pause for 5 seconds
			Thread.sleep(5000);
		
			// Take screenshot
			obj.takeScreenshot();
		
			// Search equipment name in search bar
			obj.EnterEquipSearchBar();
		
			// Pause for 5 seconds
			Thread.sleep(5000);
		
			// Change Equipment Status to Installed
			obj.SelectInstalledStatus();
			
			// Pause for 5 seconds
			Thread.sleep(5000);
		
			// Take screenshot
			obj.takeScreenshot();	
		
		} catch (PO_Common.stepFailure e) {
			driver.quit();
			Assert.fail("Test failed due to step error.");
		}
		
		
		//This timeout is used to specify the time the driver should wait while 
		//searching for an element if it is not immediately present.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.close();

	}
}
