package  CMMS.SetupTest1.TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import  CMMS.SetupTest1.PageObjects.PO_Common;
import  CMMS.SetupTest1.TestCases.Utils.BrowserManager;

public class TC_01_OpenClickAllTabs
{
	String url ="https://www.leanbiologix.com/";
	@Test
	@Parameters ({"browser", "url"})
	public void t_01_clickall(String browser, String url) {
		//better framework
		WebDriver driver = BrowserManager.getDriver(browser,url);
		PO_Common obj = PageFactory.initElements(driver, PO_Common.class);
		obj.ClickAboutButtonTest();
		
		//This timeout is used to specify the time the driver should wait while 
		//searching for an element if it is not immediately present.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.close();

	}
}