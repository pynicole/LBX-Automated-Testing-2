package CMMS.SetupTest1.PageObjects;

import java.time.Duration;
import java.awt.AWTException;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;

import javax.imageio.ImageIO;

import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import junit.framework.Assert;

//Define the class PO_Common. It represents a common base class for Page Objects.
public class PO_Common 
{
		// Declare a member variable "driver" of type WebDriver. It will hold the web driver instance used for automation.
		WebDriver driver;
		
		// Define a constructor for the PO_Common class. It takes a WebDriver object as a parameter.
		public PO_Common(WebDriver driver) {
			// Assign the provided WebDriver instance to the member variable "driver".
			this.driver = driver;
		}	
		
		// Declare a private static member variable "timestamp" of type String.
		private static String timestamp;
		
		
	    public class stepFailure extends RuntimeException {
	        public stepFailure(String message) {
	            super(message);
	        }
	    }
		
		
		

		
		
//----- PAGE OBJECTS -------------------------------------------------------------------------------------//
//-- This is where you define the specific button, field, or section on the webpage that you want to -----//
//-- interact with. Ideally you want to section them to what type of object and in alphabetical order ----//
//-- so you can find them easily. Below is an example on how to define an object. ------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the object is and on what specific page                                  //
// @FindBy(put what html tag you want to reference: should be id/name/or xpath (xpath most preferred)     //
// private WebElement insertNameOfObjectHere;                                                             //
//--------------------------------------------------------------------------------------------------------//
	   
//****** Lean Biologix website section ******//
		
		//LBX Testing
		@FindBy(how=How.CLASS_NAME,using ="menu-item-101")
		private WebElement btn_about;		
		//driver.findElement(By.id("menu-item-101")).click();
		
		@FindBy(how=How.CLASS_NAME,using ="menu-item-108")
		private WebElement btn_services;	
		
//****** CMMS Dev website section ******//		
		
	//--- BUTTONS/TABS ---//
		
	  	//CMMS Dev: Administration dropdown button
	  	@FindBy(xpath="//*[@id=\"button-1052-btnWrap\"]")
	  	private WebElement AdminMenuDropdown;
	  	
		//CMMS Login Button
		@FindBy(id ="button-1036-btnInnerEl")
		private WebElement btn_LOGIN;	
		
		//CMMS the equipment tab
		@FindBy(xpath = "/html[@id='ext-element-6']/body[@id='ext-element-1']/div[@id='index-1026']/div[@id='index-1026-bodyWrap']/div[@id='index-1026-body']/div[@id='index-1026-innerCt']/div[@id='index-1026-targetEl']/div[@id='container-1027']/div[@id='container-1027-innerCt']/div[@id='container-1027-targetEl']/div[@id='mainmenubar-1032']/div[@id='mainmenubar-1032-innerCt']/div[@id='mainmenubar-1032-targetEl']/a[@id='button-1048']/span[@id='button-1048-btnWrap']/span[@id='button-1048-btnEl']/span[@id='button-1048-btnInnerEl']")
	    private WebElement EquipmentButton;
		
	    //CMMS Dev: Equipment dropdown menu
	    @FindBy(id="button-1048-btnInnerEl")
	  	private WebElement EquipmentMenuDropdown;
	    
	    //CMMS Dev: Equipment option in Equipment dropdown menu
	  	@FindBy(xpath = "//*[@id=\"menuitem-1112-textEl\"]")
	  	private WebElement EquipmentMenuItem;
		
		//CMMS click the equipment selection
		@FindBy(xpath = "//*[@id=\"menuitem-1112-textEl\"]")
		private WebElement EquipmentMenuItem2;	
		
	  	//CMMS Dev: Search button on search bar
	  	@FindBy(id="uxpicktriggerfield-1297-trigger-trigger")
	  	private WebElement EquipmentSearchButton;
	  	
	  	//CMMS Dev: Status dropdown button on Equipment page
	  	@FindBy(id="uxcombobox-1399-trigger-picker")
	  	private WebElement EquipStatusDropdown;
	  	
	  	//CMMS Dev: Expand left view button
	  	@FindBy(xpath="//*[@id=\"button-1298\"]")
	  	private WebElement ExpandLeftView;
	  	
	  	//CMMS Dev: Expand right view button
	  	@FindBy(xpath="//*[@id=\"button-1300\"]")
	  	private WebElement ExpandRightView;
		
	  	//CMMS Dev: New Record button on Equipment page from Equipment dropdown
	  	@FindBy(xpath="//*[@id=\"button-1246-btnIconEl\"]")
	  	private WebElement NewRecordButton;
	  	
	  	//CMMS Dev: A new pop-up message when loggin in - OK button for this
	  	@FindBy(xpath="//*[@id=\"button-1013-btnInnerEl\"]")
	  	private WebElement OKButton;
	  	
	  	//CMMS Dev: Second option on expand right view screen
	  	@FindBy(xpath="//*[@id=\"tableview-1326-record-474\"]/tbody/tr/td[2]/div")
	  	private WebElement RVSecondOption;
	  	
	  	//CMMS Dev: Save Record button
	  	@FindBy(xpath="//*[@id=\"button-1245-btnIconEl\"]")
	  	private WebElement SaveRecordButton;
	  	
	  	//CMMS Dev: Security menu option on Administration dropdown menu
	  	@FindBy(xpath="//*[@id=\"menuitem-1137-itemEl\"]")
	  	private WebElement SecurityMenuItem;
	  	
	  	//CMMS Dev: Installed option on Status dropdown on Equipment page
	  	@FindBy(xpath="//li[contains(@class, 'x-boundlist-item') and text()='Installed']")
	  	private WebElement StatusInstalledOption; 
	  	
	  	//CMMS Dev: User Group menu option under Security on Administration dropdown menu
	  	@FindBy(xpath="//*[@id=\"menuitem-1264-textEl\"]")
	  	private WebElement UserGroupMenuItem;
	  	
	  	//CMMS Dev: Search button on search bar on User Group page
	  	@FindBy(xpath="//*[@id=\"uxpicktriggerfield-1323-trigger-trigger\"]")
	  	private WebElement UserGroupSearchButton;
	  	
	  	//CMMS Dev: Run button for Users search bar on User Group page
	  	@FindBy(xpath="//*[@id=\"button-1475-btnInnerEl\"]")
	  	private WebElement UserGroupUsersRun;
	  	
	  	//CMMS Dev: Users tab on User Group page
	  	@FindBy(xpath="//*[@id=\"tab-1383-btnInnerEl\"]")
	  	private WebElement UserGroupUsersTab;
		
		
	//--- USER FIELDS ---//
	  	
	  	//CMMS Dev: Field for Equipment Department
	  	@FindBy(xpath="//*[@id=\"lovfield-1417-inputEl\"]")
	  	private WebElement EquipmentDeptField;
		
	  	//CMMS Dev: Field for Equipment Description
	  	@FindBy(xpath="//*[@id=\"textfield-1396-inputEl\"]")
	  	private WebElement EquipmentDescField;
	  	
	  	//CMMS Dev: Field for Equipment Name
	  	@FindBy(xpath="//*[@id=\"textfield-1395-inputEl\"]")
	  	private WebElement EquipmentNameField;	 
	  	
	  	//CMMS Dev: Field for Equipment Type
	  	@FindBy(xpath="//*[@id=\"lovfield-1406-inputEl\"]")
	  	private WebElement EquipmentTypeField;
		
		//CMMS Testing Biogen, "password field"
		@FindBy(id="textfield-1035-inputEl")
		private WebElement PasswordField;
		
		//CMMS Testing Biogen, "User Id field"
		@FindBy(id ="textfield-1034-inputEl")
		private WebElement UserField;
		
		
	//--- SEARCH BARS / SEARCH BAR SELECTION ---//
		
	  	//CMMS Dev: Equipment search bar
	  	@FindBy(name="summarysearch")
	  	private WebElement EquipmentSearchBar;
	  	
	  	//CMMS Dev: First selection on search bar
	  	@FindBy(xpath = "//*[@id=\"ext-element-27\"]")
	  	private WebElement FirstSearchOption;
	  	
	  	//CMMS Dev: Second option in search bar
	  	@FindBy(xpath="//*[@id=\"uxgridsummaryview-1816\"]/div[2]")
	  	private WebElement SecondSearchOption;
	  	
	  	//CMMS Dev: Search bar on User Group page
	  	@FindBy(xpath="//*[@id=\"uxpicktriggerfield-1323-inputEl\"]")
	  	private WebElement UserGroupSearchBar;
	  	
	  	//CMMS Dev: Users search bar on User Group page
	  	@FindBy(xpath="//*[@id=\"textfield-1506-inputEl\"]")
	  	private WebElement UserGroupUsersSearch;
		
		
		
		
		
//----- METHODS ------------------------------------------------------------------------------------------//
//-- This is where you define the specific methods (actions) that you want to do to the webpage. ---------//
//-- Ideally you want to section them to what type of method it is and in alphabetical order -------------//
//-- so you can find them easily. Below is an example on how to define a method. -------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the action is to what page objects                                       //
// public void nameOfActionHere() {                                                                       //
//     try {                                                                                              //
//	        nameOfPageObjectYouWant.click() or .sendKeys(wordYouWantToEnter)                              //
//	  	    refreshTimestamp();   (used to get the current time)                                          //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//  	    Reporter.log("This should be the "Actual" result of the action being done", true);            //
//  	    Reporter.log(timestamp, true);    (timestamps the action to the current time)                 //
//     } catch (Exception e) {                                                                            //
//          e.printStackTrace();    (will output the error if an error occurs)                            //
//          refreshTimestamp();                                                                           //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//		    Reporter.log("Step failed.", true);                                                           //
//		    Reporter.log(timestamp, true);                                                                //
//          throw new stepFailure("Step failed."); (stops the test and marks as failure)                  //
//     }                                                                                                  //
// }                                                                                                      //
//--------------------------------------------------------------------------------------------------------// 
	  	
	  	
//****** Commonly used methods ******//		
	  	
	  	
	  	private static void refreshTimestamp() {
	        // Update the timestamp with the current date and time
	        timestamp = new SimpleDateFormat("dd-MMM-yy HH:mm:ss").format(new Date());
	    }
	  	
	  	public void takeScreenshotWithTaskbar() {
	  	    try {
	  	        // Create a Robot object to capture the screen pixels
	  	        Robot robot = new Robot();

	  	        // Determine the size of the screen
	  	        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());

	  	        // Capture the screen shot of the entire screen
	  	        BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
	  	        
	  	        // Generate a unique file name based on the current timestamp
	  	        String fileName = "screenshot_" + getTimestamp() + ".jpg";

	  	        File destination = new File("C:\\Users\\nrodgers\\Automated Testing Screenshots\\" + fileName);

	  	        // Save the screenshot to the specified location
	  	        ImageIO.write(screenFullImage, "jpg", destination);
	  	        
	  	        System.out.println("Screenshot captured: " + destination.getAbsolutePath());
	  	        refreshTimestamp();

	  	        // Convert the screenshot to Base64 encoded string
	  	        String base64Screenshot = convertToBase64(destination);

	  	        // Embed the screenshot image into the TestNG report using <img> tag with Base64 data
	  	        String imgTag = "<img src=\"data:image/jpeg;base64," + base64Screenshot + "\" alt=\"Screenshot\" height=\"250\" />";
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Screenshot captured: </br>" + imgTag, true);
	  	        Reporter.log(timestamp, true);

	  	        // adding the img to an array to be called on later
	  	        imgTags.add(imgTag);
	  	        
	  	    } catch (Exception ex) {
	  	        ex.printStackTrace();
	  	        
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	    }
	  	}
	  	
	  	public void takeScreenshot() {
	  	    if (driver instanceof TakesScreenshot) {
	  	        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	  	        // Generate a unique file name based on the current timestamp
	  	        String fileName = "screenshot_" + getTimestamp() + ".jpg";

	  	        File destination = new File("D:\\Users\\nrodgers\\Automated Testing Screenshots\\" + fileName); // Customize the screenshot file destination

	  	        try {
	  	            // Adjust the dimensions to capture the entire screen including the taskbar
	  	            BufferedImage fullScreen = ImageIO.read(screenshot);
	  	            Robot robot = new Robot();
	  	            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
	  	            BufferedImage combinedImage = new BufferedImage(screenRect.width, screenRect.height, BufferedImage.TYPE_INT_ARGB);
	  	            Graphics2D g2d = combinedImage.createGraphics();
	  	            g2d.drawImage(fullScreen, 0, 0, null);
	  	            g2d.dispose();

	  	            // Save the combined screenshot
	  	            ImageIO.write(combinedImage, "png", destination);

	  	            System.out.println("Screenshot captured: " + destination.getAbsolutePath());
	  	            refreshTimestamp();

	  	            // Convert the screenshot to Base64 encoded string
	  	            String base64Screenshot = convertToBase64(destination);

	  	            // Embed the screenshot image into the TestNG report using <img> tag with Base64 data
	  	            String imgTag = "<img src=\"data:image/png;base64," + base64Screenshot + "\" alt=\"Screenshot\" />";
	  	            Reporter.log("Take a screenshot.", true);
	  	            Reporter.log("Screenshot captured: </br>" + imgTag, true);
	  	            Reporter.log(timestamp, true);
	  	            // adding the img to an array to be called on later
	  	            imgTags.add(imgTag);

	  	        } catch (IOException e) {
	                e.printStackTrace();
	                
	                Reporter.log("Take a screenshot.", true);
	                Reporter.log("Step failed.", true);
	                Reporter.log(timestamp, true);
	            } catch (AWTException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
					Reporter.log("Take a screenshot.", true);
	                Reporter.log("Step failed.", true);
	                Reporter.log(timestamp, true);
				}
	  	    }
	  	}
	  	
	    public void takeScreenshot2() {
	        if (driver instanceof TakesScreenshot) {
	            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	            // Generate a unique file name based on the current timestamp
	            String fileName = "screenshot_" + getTimestamp() + ".jpg";

	            File destination = new File("D:\\Users\\nrodgers\\Automated Testing Screenshots\\" + fileName); // Customize the screenshot file destination

	            try {
	                Files.copy(screenshot.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
	                System.out.println("Screenshot captured: " + destination.getAbsolutePath());
	                refreshTimestamp();

	                // Embed the screenshot image into the TestNG report using <img> tag
	                String screenshotURL = "file:///" + destination.getAbsolutePath();
	                String imgTag = "<img src=\"" + screenshotURL + "\" alt=\"Screenshot\" height=\"200\" />";
	                Reporter.log("Take a screenshot.", true);
	                Reporter.log("Screenshot captured: </br>" + imgTag, true);
	                Reporter.log(timestamp, true);
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    
	  	
	    
	    public void takeScreenshot3() {
	        if (driver instanceof TakesScreenshot) {
	            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	            // Generate a unique file name based on the current timestamp
	            String fileName = "screenshot_" + getTimestamp() + ".jpg";

	            File destination = new File("D:\\Users\\nrodgers\\Automated Testing Screenshots\\" + fileName); // Customize the screenshot file destination

	            try {
	                Files.copy(screenshot.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
	                System.out.println("Screenshot captured: " + destination.getAbsolutePath());
	                refreshTimestamp();

	                // Convert the screenshot to Base64 encoded string
	                String base64Screenshot = convertToBase64(destination);

	                // Embed the screenshot image into the TestNG report using <img> tag with Base64 data
	                String imgTag = "<img src=\"data:image/jpeg;base64," + base64Screenshot + "\" alt=\"Screenshot\" height=\"200\" />";
	                Reporter.log("Take a screenshot.", true);
	                Reporter.log("Screenshot captured: </br>" + imgTag, true);
	                Reporter.log(timestamp, true);
	                // adding the img to an array to be called on later
	                imgTags.add(imgTag);
	                
	             
	            } catch (IOException e) {
	                e.printStackTrace();
	                
	                Reporter.log("Take a screenshot.", true);
	                Reporter.log("Step failed.", true);
	                Reporter.log(timestamp, true);
	            }
	        }
	    }
	    
	    

	    private String convertToBase64(File file) throws IOException {
	        byte[] fileContent = Files.readAllBytes(file.toPath());
	        return Base64.getEncoder().encodeToString(fileContent);
	    }
	

		private String getTimestamp() {
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		    return sdf.format(new Date());
		}
		
	  	public ArrayList<String> imgTags = new ArrayList<>();

	    // Getter method to access the imgTags ArrayList
	    public ArrayList<String> getImgTags() {
	        return imgTags;
	    }
	  	
	  	
	  	
//****** CMMS Dev website section ******//	
		
		
	//---------- LOGIN ----------//
		
		//Biogen enter username and password and login to dev CMMS
		public void Login_To_CMMS_Dev(WebDriver driver, String username, String password) throws InterruptedException 
		{
			
			EnterUsername(username); 	

			EnterPassword(password); 	
			
			btn_LOGIN.click(); 	
			

			//watch this video, figure out how to reference driver in this method
			//https://www.youtube.com/watch?v=evRGeTo8TME
			
			//Close the browser
			//driver.quit();
	
		}
	  	
	//---------- CLICK ----------//
		
		//CMMS Dev: Click Administration dropdown menu
		public void ClickAdminDropdown() {
			try {
				AdminMenuDropdown.click();
				//NewRecordButton.click();
				refreshTimestamp();
				Reporter.log("Click Administration dropdown menu. ", true);
				Reporter.log("Administration dropdown menu clicked.", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
			    e.printStackTrace();
			    
				refreshTimestamp();
				Reporter.log("Click Administration dropdown menu. ", true);
				Reporter.log("Step failed", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
	  	
		//CMMS Dev: Click Equipment dropdown menu
		public void ClickEquipmentMenu() {
			try {
				EquipmentMenuDropdown.click();
				refreshTimestamp();
				Reporter.log("Click Equipment dropdown. " ,true);
				Reporter.log("Equipment dropdown clicked. " ,true);
				Reporter.log(timestamp,true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click Equipment dropdown. " ,true);
				Reporter.log("Step failed. " ,true);
				Reporter.log(timestamp,true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click Equipment on Equipment dropdown menu
		public void ClickEquipmentSelection() {
			try {
				EquipmentMenuItem.click();
				refreshTimestamp();
				Reporter.log("Click Equipment menu selection. ",true);
				Reporter.log("Equipment option selected. ",true);
				Reporter.log(timestamp,true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click Equipment menu selection. ",true);
				Reporter.log("Step failed. ",true);
				Reporter.log(timestamp,true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
	  	
		//CMMS - login button clicking
		public void ClickLoginButton() {
			try {
				btn_LOGIN.click();
				refreshTimestamp();
				Reporter.log("Click CMMS Dev login button. " ,true);
				Reporter.log("Login button clicked. " ,true);
				Reporter.log(timestamp ,true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click CMMS Dev login button. " ,true);
				Reporter.log("Step failed. " ,true);
				Reporter.log(timestamp ,true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click New Record button
		public void ClickNewRecord() {
			try {
				NewRecordButton.click();
				refreshTimestamp();
				Reporter.log("Click New Record button. ", true);	
				Reporter.log("New Record button clicked. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click New Record button. ", true);	
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click New Record button
		public void ClickOKButton() {
			try {
				OKButton.click();
				//refreshTimestamp();
				//Reporter.log("Click New Record button. ", true);	
				//Reporter.log("New Record button clicked. ", true);
				//Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        //refreshTimestamp();
				//Reporter.log("Click New Record button. ", true);	
				//Reporter.log("Step failed. ", true);
				//Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click Save Record button
		public void ClickSaveRecord() {
			try {
				SaveRecordButton.click();
				refreshTimestamp();
				Reporter.log("Click Save Record button. ", true);
				Reporter.log("Save Record button clicked. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click Save Record button. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click Security menu item
		public void ClickSecurityMenuItem() {
			try {
				SecurityMenuItem.click();
				refreshTimestamp();
				Reporter.log("Click Security menu item. ", true);
				Reporter.log("Security option clicked. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click Security menu item. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);	
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click User Group menu item
		public void ClickUserGroupMenuItem() {
			try {
				UserGroupMenuItem.click();
				refreshTimestamp();
				Reporter.log("Click User Group menu item. ", true);
				Reporter.log("User Group option clicked. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click User Group menu item. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click search bar on User Group page
		public void ClickUserGroupSearchBar() {
			try {
				UserGroupSearchBar.click();
				refreshTimestamp();
				Reporter.log("Click search bar on User Group page. ", true);
				Reporter.log("Search bar clicked.", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click search bar on User Group page. ", true);
				Reporter.log("Step failed.", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click search bar on Users tab on user Group page
		public void ClickUsersSearchBar() {
			try {
				UserGroupUsersSearch.click();
				refreshTimestamp();
				Reporter.log("Clicked search bar on Users tab on User Group page. ", true);
				Reporter.log("Search bar clicked. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Clicked search bar on Users tab on User Group page. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click Users tab on user Group page
		public void ClickUsersTab() {
			try {
				UserGroupUsersTab.click();
				refreshTimestamp();
				Reporter.log("Click Users tab on User Group page. ", true);
				Reporter.log("Users tab clicked. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click Users tab on User Group page. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Select Installed option for Status on Equipment page
		public void SelectInstalledStatus() {
			try {
				EquipStatusDropdown.click();
				StatusInstalledOption.click();
				refreshTimestamp();
				Reporter.log("Change Equipment Status to Installed. ", true);
				Reporter.log("Equipment status changed to Installed. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Change Equipment Status to Installed. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click first option on search bar.
		public void SelectFirstOption() {
			try {
				FirstSearchOption.click();
				refreshTimestamp();
				Reporter.log("Click first option within search. ", true);
				Reporter.log("First option selected. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click first option within search. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click second option on search bar
		public void SelectSecondOption() {
			try {
				ExpandRightView.click();
				RVSecondOption.click();
				ExpandLeftView.click();
				refreshTimestamp();
				Reporter.log("Click second option within search. ", true);
				Reporter.log("Second option selected. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click second option within search. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
	  	
		
	//---------- SENDKEYS ----------//
		
		//CMMS Dev: Enter details to Equipment Department field
		public void EnterEquipmentDept() {
			try {
				EquipmentDeptField.sendKeys("*");
				refreshTimestamp();
				Reporter.log("Enter Equipment Department. ", true);
				Reporter.log("Equipment Department entered. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Enter Equipment Department. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Enter details to Equipment Description field
		public void EnterEquipmentDesc() {
			try {
				EquipmentDescField.sendKeys("Automated Test Desc 0001");
				refreshTimestamp();
				Reporter.log("Enter Equipment Description. ", true);
				Reporter.log("Equipment Description entered. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Enter Equipment Description. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Enter details to Equipment Name field
		public void EnterEquipmentName() {
			try {
				EquipmentNameField.sendKeys("Automated Test 0001");
				refreshTimestamp();
				Reporter.log("Enter Equipment Name. ", true);
				Reporter.log("Equipment Name entered. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Enter Equipment Name. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Click search bar on Equipment page
		public void EnterEquipSearchBar() {
			try {
				EquipmentSearchBar.click();
				EquipmentSearchBar.sendKeys("Automated Test 0001");
				EquipmentSearchButton.click();
				refreshTimestamp();
				Reporter.log("Enter equipment name in search bar. " , true);
				Reporter.log("Equipment name searched. " , true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Enter equipment name in search bar. " , true);
				Reporter.log("Step failed. " , true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Enter details to Equipment Type field
		public void EnterEquipmentType() {
			try {
				EquipmentTypeField.sendKeys("FS");
				refreshTimestamp();
				Reporter.log("Enter Equipment Type. ", true);
				Reporter.log("Equipment Type entered. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Enter Equipment Type. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
	  	
		//CMMS - send the password to the field
		public void EnterPassword(String password) {
			try {
				PasswordField.sendKeys(password);
				refreshTimestamp();
				Reporter.log("Entered Password. ", true);
	  	        Reporter.log("Password entered successfully. ", true);
	  	        Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Entered Password. ", true);
	  	        Reporter.log("Step failed. ", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Enter User Group into search bar
		public void EnterUserGroup() {
			try {
				UserGroupSearchBar.click();
				UserGroupSearchBar.sendKeys("BUSADMIN");
				UserGroupSearchButton.click();
				refreshTimestamp();
				Reporter.log("Enter BUSADMIN in search bar. ", true);
				Reporter.log("BUSADMIN entered in search bar.", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Enter BUSADMIN in search bar. ", true);
				Reporter.log("Step failed.", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS Dev: Enter user in search bar on Users tab on User Group page.
		public void EnterUserInfo() {
			try {
				UserGroupUsersSearch.sendKeys("NRODGERS");
				UserGroupUsersRun.click();
				refreshTimestamp();
				Reporter.log("Entered search for user NRODGERS on Users tab on User Group page. ", true);
				Reporter.log("Searched for user NRODGERS. ", true);
				Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	      refreshTimestamp();
				Reporter.log("Entered search for user NRODGERS on Users tab on User Group page. ", true);
				Reporter.log("Step failed. ", true);
				Reporter.log(timestamp, true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
	  	
		//CMMS - send the user name to the field
	  	public void EnterUsername(String username) {
	  	    try {
	  	        UserField.sendKeys(username);
	  	        refreshTimestamp();
	  	        Reporter.log("Entered Username. ", true);
	  	        Reporter.log("Username entered successfully. ", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Entered Username. ", true);
	  	        Reporter.log("Step failed. ", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	

//****** Lean Biologix website section ******//	
		
		// define some method to define success clicking lbx page menu buttons and use assert
		public void ClickAboutButtonTest() {
			//ClickAboutButton();
			
			//data validation using the title, confirms it goes to the right page and the page loads
			String actual = driver.getTitle();
			String expected = "GAMP 5, Pharmaceutical Packaging, Boston MA, Lean Biologix";
			Assert.assertEquals(actual, expected);
			
			//logging entry
			Reporter.log("Business Method to click button was successful",true);
			
			//This waits up to 10 seconds before throwing a TimeoutException 
			//or if it finds the element will return it in 0 - 10 seconds
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-item-101")));
		}
}
